import fs from 'node:fs';
const read=n=>JSON.parse(fs.readFileSync(new URL(n,import.meta.url),'utf8'));
const num=s=>{if(!s||s==='—')return null;let x=s.replaceAll('−','-').replaceAll(',','').replace(/\s|PKR|%/g,'');let m=x.match(/^([+-]?[\d.]+)([KMBT])?$/);return m?Number(m[1])*({K:1e3,M:1e6,B:1e9,T:1e12}[m[2]]||1):null};
const psx=new Map(read('psx.json').filter(r=>!r[0].includes('NC')).map(r=>[r[0].split(/\s/)[0],r]));
const tech=new Map(read('technicals.json').map(r=>[r[0].split('\n')[0],r]));
const perf=new Map(read('performance.json').map(r=>[r[0].split('\n')[0],r]));
let rows=read('overview.json').map(o=>{let c=o.cells,t=o.links[0].text,p=psx.get(t),a=tech.get(t),f=perf.get(t);if(!p||!a)return null;return {ticker:t,company:o.links[1].text,url:o.links[0].url,price:num(c[1]),change:num(c[2]),volume:num(c[3]),relvol:num(c[4]),mcap:num(c[5]),pe:num(c[6]),eps:num(c[7]),growth:num(c[8]),yield:num(c[9]),sector:c[10],avgvol:num(p[8]),technical:a[1],ma:a[2],osc:a[3],rsi:num(a[4]),momentum:num(a[5]),ao:num(a[6]),cci:num(a[7]),stochK:num(a[8]),stochD:num(a[9]),macd:num(a[10]),signal:num(a[11]),perf:f};}).filter(Boolean);
for(let r of rows){r.score=({ 'Strong buy':20,Buy:15,Neutral:7,Sell:0,'Strong sell':-5}[r.technical]||0)+({'Strong buy':15,Buy:10,Neutral:4,Sell:0,'Strong sell':-5}[r.ma]||0)+(r.macd>r.signal?10:0)+(r.momentum>0?10:0)+(r.rsi>=50&&r.rsi<=68?10:r.rsi>68&&r.rsi<=75?4:0)+(r.relvol>=1.5?10:r.relvol>=1?6:0)+(r.change>0?5:0)+(r.eps>0?5:0)+(r.growth>0?5:0)+(r.avgvol>=1e6?5:r.avgvol>=1e5?3:0)+(r.stochK>r.stochD?5:0);}
rows=rows.filter(r=>r.volume>=25000&&r.avgvol>=100000&&r.mcap>=1e9&&r.price>=5).sort((a,b)=>b.score-a.score||b.avgvol-a.avgvol);
fs.writeFileSync(new URL('screened.json',import.meta.url),JSON.stringify(rows,null,2));
console.log(JSON.stringify({eligible:rows.length,top:rows.slice(0,65).map(({ticker,score,technical,ma,rsi,relvol,growth,pe,avgvol})=>({ticker,score,technical,ma,rsi,relvol,growth,pe,avgvol}))},null,2));
